<?php

//homepage images
td_demo_media::add_image_to_media_gallery('header',                     "http://demo_content.tagdiv.com/Newspaper_multi/dentist/header.png");
td_demo_media::add_image_to_media_gallery('instruments',                "http://demo_content.tagdiv.com/Newspaper_multi/dentist/instruments.jpg");

//customers page images
td_demo_media::add_image_to_media_gallery('alex',                       "http://demo_content.tagdiv.com/Newspaper_multi/dentist/alex.jpg");
td_demo_media::add_image_to_media_gallery('brooke',                     "http://demo_content.tagdiv.com/Newspaper_multi/dentist/brooke.jpg");
td_demo_media::add_image_to_media_gallery('jane',                       "http://demo_content.tagdiv.com/Newspaper_multi/dentist/jane.jpg");
td_demo_media::add_image_to_media_gallery('paul',                       "http://demo_content.tagdiv.com/Newspaper_multi/dentist/paul.jpg");

//bg images
td_demo_media::add_image_to_media_gallery('hd',                         "http://demo_content.tagdiv.com/Newspaper_multi/dentist/xxx_hd_xxx.jpg");
td_demo_media::add_image_to_media_gallery('team',                       "http://demo_content.tagdiv.com/Newspaper_multi/dentist/xxx_team_xxx.jpg");