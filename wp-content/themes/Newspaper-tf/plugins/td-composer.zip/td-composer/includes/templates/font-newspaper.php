<span data-font_class="td-icon-logout"><i class="td-icon-logout"></i></span>
<span data-font_class="td-icon-down"><i class="td-icon-down"></i></span>
<span data-font_class="td-icon-left"><i class="td-icon-left"></i></span>
<span data-font_class="td-icon-right"><i class="td-icon-right"></i></span>
<span data-font_class="td-icon-up"><i class="td-icon-up"></i></span>
<span data-font_class="td-icon-views"><i class="td-icon-views"></i></span>
<span data-font_class="td-icon-menu-down"><i class="td-icon-menu-down"></i></span>
<span data-font_class="td-icon-left-arrow"><i class="td-icon-left-arrow"></i></span>
<span data-font_class="td-icon-right-arrow"><i class="td-icon-right-arrow"></i></span>
<span data-font_class="td-icon-menu-up"><i class="td-icon-menu-up"></i></span>
<span data-font_class="td-icon-search"><i class="td-icon-search"></i></span>
<span data-font_class="td-icon-user"><i class="td-icon-user"></i></span>
<span data-font_class="td-icon-menu-left"><i class="td-icon-menu-left"></i></span>
<span data-font_class="td-icon-menu-right"><i class="td-icon-menu-right"></i></span>
<span data-font_class="td-icon-star"><i class="td-icon-star"></i></span>
<span data-font_class="td-icon-mail"><i class="td-icon-mail"></i></span>
<span data-font_class="td-icon-behance"><i class="td-icon-behance"></i></span>
<span data-font_class="td-icon-blogger"><i class="td-icon-blogger"></i></span>
<span data-font_class="td-icon-delicious"><i class="td-icon-delicious"></i></span>
<span data-font_class="td-icon-deviantart"><i class="td-icon-deviantart"></i></span>
<span data-font_class="td-icon-digg"><i class="td-icon-digg"></i></span>
<span data-font_class="td-icon-dribbble"><i class="td-icon-dribbble"></i></span>
<span data-font_class="td-icon-evernote"><i class="td-icon-evernote"></i></span>
<span data-font_class="td-icon-facebook"><i class="td-icon-facebook"></i></span>
<span data-font_class="td-icon-flickr"><i class="td-icon-flickr"></i></span>
<span data-font_class="td-icon-forrst"><i class="td-icon-forrst"></i></span>
<span data-font_class="td-icon-googleplus"><i class="td-icon-googleplus"></i></span>
<span data-font_class="td-icon-instagram"><i class="td-icon-instagram"></i></span>
<span data-font_class="td-icon-lastfm"><i class="td-icon-lastfm"></i></span>
<span data-font_class="td-icon-linkedin"><i class="td-icon-linkedin"></i></span>
<span data-font_class="td-icon-mail-1"><i class="td-icon-mail-1"></i></span>
<span data-font_class="td-icon-myspace"><i class="td-icon-myspace"></i></span>
<span data-font_class="td-icon-path"><i class="td-icon-path"></i></span>
<span data-font_class="td-icon-paypal"><i class="td-icon-paypal"></i></span>
<span data-font_class="td-icon-pinterest"><i class="td-icon-pinterest"></i></span>
<span data-font_class="td-icon-reddit"><i class="td-icon-reddit"></i></span>
<span data-font_class="td-icon-rss"><i class="td-icon-rss"></i></span>
<span data-font_class="td-icon-share"><i class="td-icon-share"></i></span>
<span data-font_class="td-icon-skype"><i class="td-icon-skype"></i></span>
<span data-font_class="td-icon-soundcloud"><i class="td-icon-soundcloud"></i></span>
<span data-font_class="td-icon-spotify"><i class="td-icon-spotify"></i></span>
<span data-font_class="td-icon-stackoverflow"><i class="td-icon-stackoverflow"></i></span>
<span data-font_class="td-icon-steam"><i class="td-icon-steam"></i></span>
<span data-font_class="td-icon-stumbleupon"><i class="td-icon-stumbleupon"></i></span>
<span data-font_class="td-icon-tumblr"><i class="td-icon-tumblr"></i></span>
<span data-font_class="td-icon-twitter"><i class="td-icon-twitter"></i></span>
<span data-font_class="td-icon-vimeo"><i class="td-icon-vimeo"></i></span>
<span data-font_class="td-icon-windows"><i class="td-icon-windows"></i></span>
<span data-font_class="td-icon-wordpress"><i class="td-icon-wordpress"></i></span>
<span data-font_class="td-icon-yahoo"><i class="td-icon-yahoo"></i></span>
<span data-font_class="td-icon-youtube"><i class="td-icon-youtube"></i></span>
<span data-font_class="td-icon-vk"><i class="td-icon-vk"></i></span>
<span data-font_class="td-icon-grooveshark"><i class="td-icon-grooveshark"></i></span>
<span data-font_class="td-icon-star-empty"><i class="td-icon-star-empty"></i></span>
<span data-font_class="td-icon-star-half"><i class="td-icon-star-half"></i></span>
<span data-font_class="td-icon-close"><i class="td-icon-close"></i></span>
<span data-font_class="td-icon-read-down"><i class="td-icon-read-down"></i></span>
<span data-font_class="td-icon-comments"><i class="td-icon-comments"></i></span>
<span data-font_class="td-icon-mobile"><i class="td-icon-mobile"></i></span>
<span data-font_class="td-icon-whatsapp"><i class="td-icon-whatsapp"></i></span>
<span data-font_class="td-icon-commenting"><i class="td-icon-commenting"></i></span>
<span data-font_class="td-icon-close-mobile"><i class="td-icon-close-mobile"></i></span>
<span data-font_class="td-icon-modal-back"><i class="td-icon-modal-back"></i></span>
<span data-font_class="td-icon-modal-close"><i class="td-icon-modal-close"></i></span>
<span data-font_class="td-icon-category"><i class="td-icon-category"></i></span>
<span data-font_class="td-icon-block-header"><i class="td-icon-block-header"></i></span>
<span data-font_class="td-icon-home"><i class="td-icon-home"></i></span>
<span data-font_class="td-icon-print"><i class="td-icon-print"></i></span>
<span data-font_class="td-icon-telegram"><i class="td-icon-telegram"></i></span>
<span data-font_class="td-icon-line"><i class="td-icon-line"></i></span>
<span data-font_class="td-icon-viber"><i class="td-icon-viber"></i></span>
<span data-font_class="td-icon-plus"><i class="td-icon-plus"></i></span>
<span data-font_class="td-icon-minus"><i class="td-icon-minus"></i></span>
<span data-font_class="td-icon-dailymotion"><i class="td-icon-dailymotion"></i></span>
<span data-font_class="td-icon-twitch"><i class="td-icon-twitch"></i></span>
<span data-font_class="td-icon-xing"><i class="td-icon-xing"></i></span>
<span data-font_class="td-icon-ebay"><i class="td-icon-ebay"></i></span>
<span data-font_class="td-icon-acolade"><i class="td-icon-acolade"></i></span>
<span data-font_class="td-icon-backslash"><i class="td-icon-backslash"></i></span>
<span data-font_class="td-icon-bracket-square"><i class="td-icon-bracket-square"></i></span>
<span data-font_class="td-icon-circle-full"><i class="td-icon-circle-full"></i></span>
<span data-font_class="td-icon-circle-line"><i class="td-icon-circle-line"></i></span>
<span data-font_class="td-icon-circless"><i class="td-icon-circless"></i></span>
<span data-font_class="td-icon-comma-round"><i class="td-icon-comma-round"></i></span>
<span data-font_class="td-icon-comma-square"><i class="td-icon-comma-square"></i></span>
<span data-font_class="td-icon-hash"><i class="td-icon-hash"></i></span>
<span data-font_class="td-icon-linee"><i class="td-icon-linee"></i></span>
<span data-font_class="td-icon-pluss"><i class="td-icon-pluss"></i></span>
<span data-font_class="td-icon-point-comma-round"><i class="td-icon-point-comma-round"></i></span>
<span data-font_class="td-icon-point-comma-square"><i class="td-icon-point-comma-square"></i></span>
<span data-font_class="td-icon-point-round"><i class="td-icon-point-round"></i></span>
<span data-font_class="td-icon-point-square"><i class="td-icon-point-square"></i></span>
<span data-font_class="td-icon-quote-round"><i class="td-icon-quote-round"></i></span>
<span data-font_class="td-icon-quote-square"><i class="td-icon-quote-square"></i></span>
<span data-font_class="td-icon-romb-full"><i class="td-icon-romb-full"></i></span>
<span data-font_class="td-icon-romb-line"><i class="td-icon-romb-line"></i></span>
<span data-font_class="td-icon-romb-round-full"><i class="td-icon-romb-round-full"></i></span>
<span data-font_class="td-icon-romb-round-line"><i class="td-icon-romb-round-line"></i></span>
<span data-font_class="td-icon-rombs"><i class="td-icon-rombs"></i></span>
<span data-font_class="td-icon-slashh"><i class="td-icon-slashh"></i></span>
<span data-font_class="td-icon-star-full"><i class="td-icon-star-full"></i></span>
<span data-font_class="td-icon-star-line"><i class="td-icon-star-line"></i></span>
<span data-font_class="td-icon-translingual"><i class="td-icon-translingual"></i></span>
<span data-font_class="td-icon-upp"><i class="td-icon-upp"></i></span>
<span data-font_class="td-icon-vertical-line"><i class="td-icon-vertical-line"></i></span>

<span data-font_class="td-icon-dots-circle-big"><i class="td-icon-dots-circle-big"></i></span>
<span data-font_class="td-icon-dots-circle-line"><i class="td-icon-dots-circle-line"></i></span>
<span data-font_class="td-icon-dots-circle-line-medium"><i class="td-icon-dots-circle-line-medium"></i></span>
<span data-font_class="td-icon-dots-circle-medium"><i class="td-icon-dots-circle-medium"></i></span>
<span data-font_class="td-icon-dots-circle-united-line"><i class="td-icon-dots-circle-united-line"></i></span>
<span data-font_class="td-icon-dots-romb"><i class="td-icon-dots-romb"></i></span>
<span data-font_class="td-icon-dots-romb-big"><i class="td-icon-dots-romb-big"></i></span>
<span data-font_class="td-icon-dots-romb-line"><i class="td-icon-dots-romb-line"></i></span>
<span data-font_class="td-icon-dots-romb-united"><i class="td-icon-dots-romb-united"></i></span>
<span data-font_class="td-icon-dots-romb-united-line"><i class="td-icon-dots-romb-united-line"></i></span>
<span data-font_class="td-icon-dots-square"><i class="td-icon-dots-square"></i></span>
<span data-font_class="td-icon-dots-square-big"><i class="td-icon-dots-square-big"></i></span>
<span data-font_class="td-icon-dots-square-line"><i class="td-icon-dots-square-line"></i></span>
<span data-font_class="td-icon-dots-square-line-big"><i class="td-icon-dots-square-line-big"></i></span>
<span data-font_class="td-icon-dots-square-medium"><i class="td-icon-dots-square-medium"></i></span>
<span data-font_class="td-icon-magnifier-big-fill-space"><i class="td-icon-magnifier-big-fill-space"></i></span>
<span data-font_class="td-icon-magnifier-big-long-line"><i class="td-icon-magnifier-big-long-line"></i></span>
<span data-font_class="td-icon-magnifier-big-rounded"><i class="td-icon-magnifier-big-rounded"></i></span>
<span data-font_class="td-icon-magnifier-big-rounded-line"><i class="td-icon-magnifier-big-rounded-line"></i></span>
<span data-font_class="td-icon-magnifier-big-space"><i class="td-icon-magnifier-big-space"></i></span>
<span data-font_class="td-icon-magnifier-big-square-space"><i class="td-icon-magnifier-big-square-space"></i></span>
<span data-font_class="td-icon-magnifier-fill-round-space"><i class="td-icon-magnifier-fill-round-space"></i></span>
<span data-font_class="td-icon-magnifier-medium-long"><i class="td-icon-magnifier-medium-long"></i></span>
<span data-font_class="td-icon-magnifier-medium-long-light"><i class="td-icon-magnifier-medium-long-light"></i></span>
<span data-font_class="td-icon-magnifier-medium-long-line"><i class="td-icon-magnifier-medium-long-line"></i></span>
<span data-font_class="td-icon-magnifier-medium-short"><i class="td-icon-magnifier-medium-short"></i></span>
<span data-font_class="td-icon-magnifier-medium-short-light"><i class="td-icon-magnifier-medium-short-light"></i></span>
<span data-font_class="td-icon-magnifier-outline-line"><i class="td-icon-magnifier-outline-line"></i></span>
<span data-font_class="td-icon-magnifier-real-long"><i class="td-icon-magnifier-real-long"></i></span>
<span data-font_class="td-icon-magnifier-real-long-line"><i class="td-icon-magnifier-real-long-line"></i></span>
<span data-font_class="td-icon-magnifier-real-space-line"><i class="td-icon-magnifier-real-space-line"></i></span>
<span data-font_class="td-icon-magnifier-thin-long"><i class="td-icon-magnifier-thin-long"></i></span>
<span data-font_class="td-icon-magnifier-thin-short"><i class="td-icon-magnifier-thin-short"></i></span>
<span data-font_class="td-icon-menu-arrow-down"><i class="td-icon-menu-arrow-down"></i></span>
<span data-font_class="td-icon-menu-arrow-right"><i class="td-icon-menu-arrow-right"></i></span>
<span data-font_class="td-icon-menu-circle"><i class="td-icon-menu-circle"></i></span>
<span data-font_class="td-icon-menu-circle-equal"><i class="td-icon-menu-circle-equal"></i></span>
<span data-font_class="td-icon-menu-dots-circle"><i class="td-icon-menu-dots-circle"></i></span>
<span data-font_class="td-icon-menu-dots-circle-line"><i class="td-icon-menu-dots-circle-line"></i></span>
<span data-font_class="td-icon-menu-dots-romb"><i class="td-icon-menu-dots-romb"></i></span>
<span data-font_class="td-icon-menu-dots-romb-line-united"><i class="td-icon-menu-dots-romb-line-united"></i></span>
<span data-font_class="td-icon-menu-dots-romb-united"><i class="td-icon-menu-dots-romb-united"></i></span>
<span data-font_class="td-icon-menu-dots-romb-wide"><i class="td-icon-menu-dots-romb-wide"></i></span>
<span data-font_class="td-icon-menu-dots-rounded"><i class="td-icon-menu-dots-rounded"></i></span>
<span data-font_class="td-icon-menu-dots-square"><i class="td-icon-menu-dots-square"></i></span>
<span data-font_class="td-icon-menu-dots-square-line"><i class="td-icon-menu-dots-square-line"></i></span>
<span data-font_class="td-icon-menu-fill-circles"><i class="td-icon-menu-fill-circles"></i></span>
<span data-font_class="td-icon-menu-fill-squares"><i class="td-icon-menu-fill-squares"></i></span>
<span data-font_class="td-icon-menu-line-center"><i class="td-icon-menu-line-center"></i></span>
<span data-font_class="td-icon-menu-line-center-equal"><i class="td-icon-menu-line-center-equal"></i></span>
<span data-font_class="td-icon-menu-line-circles"><i class="td-icon-menu-line-circles"></i></span>
<span data-font_class="td-icon-menu-line-left"><i class="td-icon-menu-line-left"></i></span>
<span data-font_class="td-icon-menu-line-right"><i class="td-icon-menu-line-right"></i></span>
<span data-font_class="td-icon-menu-line-square-center"><i class="td-icon-menu-line-square-center"></i></span>
<span data-font_class="td-icon-menu-line-square-center-equal"><i class="td-icon-menu-line-square-center-equal"></i></span>
<span data-font_class="td-icon-menu-line-square-left"><i class="td-icon-menu-line-square-left"></i></span>
<span data-font_class="td-icon-menu-line-square-right"><i class="td-icon-menu-line-square-right"></i></span>
<span data-font_class="td-icon-menu-line-squares"><i class="td-icon-menu-line-squares"></i></span>
<span data-font_class="td-icon-menu-medium"><i class="td-icon-menu-medium"></i></span>
<span data-font_class="td-icon-menu-medium-center"><i class="td-icon-menu-medium-center"></i></span>
<span data-font_class="td-icon-menu-medium-left"><i class="td-icon-menu-medium-left"></i></span>
<span data-font_class="td-icon-menu-medium-right"><i class="td-icon-menu-medium-right"></i></span>
<span data-font_class="td-icon-menu-medium-square"><i class="td-icon-menu-medium-square"></i></span>
<span data-font_class="td-icon-menu-outline-circle"><i class="td-icon-menu-outline-circle"></i></span>
<span data-font_class="td-icon-menu-outline-circle-equal"><i class="td-icon-menu-outline-circle-equal"></i></span>
<span data-font_class="td-icon-menu-outline-rounded"><i class="td-icon-menu-outline-rounded"></i></span>
<span data-font_class="td-icon-menu-outline-rounded-square"><i class="td-icon-menu-outline-rounded-square"></i></span>
<span data-font_class="td-icon-menu-outline-square"><i class="td-icon-menu-outline-square"></i></span>
<span data-font_class="td-icon-menu-outline-square-round"><i class="td-icon-menu-outline-square-round"></i></span>
<span data-font_class="td-icon-menu-outline-square-round-lines"><i class="td-icon-menu-outline-square-round-lines"></i></span>
<span data-font_class="td-icon-menu-rounded"><i class="td-icon-menu-rounded"></i></span>
<span data-font_class="td-icon-menu-rounded-square"><i class="td-icon-menu-rounded-square"></i></span>
<span data-font_class="td-icon-menu-square"><i class="td-icon-menu-square"></i></span>
<span data-font_class="td-icon-menu-square-arrow-right"><i class="td-icon-menu-square-arrow-right"></i></span>
<span data-font_class="td-icon-menu-square-round"><i class="td-icon-menu-square-round"></i></span>
<span data-font_class="td-icon-menu-square-round-lines"><i class="td-icon-menu-square-round-lines"></i></span>
<span data-font_class="td-icon-menu-thin"><i class="td-icon-menu-thin"></i></span>
<span data-font_class="td-icon-menu-thin-center"><i class="td-icon-menu-thin-center"></i></span>
<span data-font_class="td-icon-menu-thin-left"><i class="td-icon-menu-thin-left"></i></span>
<span data-font_class="td-icon-menu-thin-right"><i class="td-icon-menu-thin-right"></i></span>
<span data-font_class="td-icon-menu-thin-square"><i class="td-icon-menu-thin-square"></i></span>
<span data-font_class="td-icon-menu-vertical"><i class="td-icon-menu-vertical"></i></span>
<span data-font_class="td-icon-box-hex"><i class="td-icon-box-hex td-size-big"></i></span>
<span data-font_class="td-icon-camera-details"><i class="td-icon-camera-details td-size-big"></i></span>
<span data-font_class="td-icon-camera-lens"><i class="td-icon-camera-lens td-size-big"></i></span>
<span data-font_class="td-icon-camera-simple"><i class="td-icon-camera-simple td-size-big"></i></span>
<span data-font_class="td-icon-check-star"><i class="td-icon-check-star td-size-big"></i></span>
<span data-font_class="td-icon-decorative-flower"><i class="td-icon-decorative-flower td-size-big"></i></span>
<span data-font_class="td-icon-drops-fill"><i class="td-icon-drops-fill td-size-big"></i></span>
<span data-font_class="td-icon-fish-pyramids"><i class="td-icon-fish-pyramids td-size-big"></i></span>
<span data-font_class="td-icon-flower-pond"><i class="td-icon-flower-pond td-size-big"></i></span>
<span data-font_class="td-icon-lines-dots"><i class="td-icon-lines-dots td-size-big"></i></span>
<span data-font_class="td-icon-lotus-fill"><i class="td-icon-lotus-fill td-size-big"></i></span>
<span data-font_class="td-icon-lotus-lines"><i class="td-icon-lotus-lines td-size-big"></i></span>
<span data-font_class="td-icon-maze-arrow"><i class="td-icon-maze-arrow td-size-big"></i></span>
<span data-font_class="td-icon-maze-hex"><i class="td-icon-maze-hex td-size-big"></i></span>
<span data-font_class="td-icon-rock-hex"><i class="td-icon-rock-hex td-size-big"></i></span>
<span data-font_class="td-icon-star-fill"><i class="td-icon-star-fill td-size-big"></i></span>
<span data-font_class="td-icon-star-flower"><i class="td-icon-star-flower td-size-big"></i></span>
<span data-font_class="td-icon-star-lines"><i class="td-icon-star-lines td-size-big"></i></span>
<span data-font_class="td-icon-tangle-fill"><i class="td-icon-tangle-fill td-size-big"></i></span>
<span data-font_class="td-icon-tangle-hex"><i class="td-icon-tangle-hex td-size-big"></i></span>
<span data-font_class="td-icon-team-work"><i class="td-icon-team-work td-size-big"></i></span>
<span data-font_class="td-icon-tree-circle"><i class="td-icon-tree-circle td-size-big"></i></span>
<span data-font_class="td-icon-tree-lines"><i class="td-icon-tree-lines td-size-big"></i></span>
<span data-font_class="td-icon-tulip-lines"><i class="td-icon-tulip-lines td-size-big"></i></span>
<span data-font_class="td-icon-vertical-leaf"><i class="td-icon-vertical-leaf td-size-big"></i></span>