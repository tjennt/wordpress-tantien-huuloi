<?php


td_demo_media::add_image_to_media_gallery('td_pic_9',                   "http://demo_content.tagdiv.com/Newspaper_6/nomad/9.jpg");

//post images
td_demo_media::add_image_to_media_gallery('td_pic_p1',                  "http://demo_content.tagdiv.com/Newspaper_6/nomad/p1.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_p2',                  "http://demo_content.tagdiv.com/Newspaper_6/nomad/p2.jpg");

// categories bg
td_demo_media::add_image_to_media_gallery('td_places_bg',               "http://demo_content.tagdiv.com/Newspaper_6/nomad/places_bg.jpg");