<?php
/**
 * Created by ra on 6/13/2015.
 */

// user photo
td_demo_media::add_image_to_media_gallery('td_profile',                 'http://demo_content.tagdiv.com/Newspaper_6/nomad/profile.jpg');