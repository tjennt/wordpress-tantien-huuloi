<?php
/**
 * Created by ra on 6/13/2015.
 */


// ads
td_demo_media::add_image_to_media_gallery('td_rec_bg',                  'http://demo_content.tagdiv.com/Newspaper_6/nomad/sidebar-rec.jpg');

// mix bgs
td_demo_media::add_image_to_media_gallery('td_home_about_bg',           'http://demo_content.tagdiv.com/Newspaper_6/nomad/home_about_bg.png');
td_demo_media::add_image_to_media_gallery('td_about_bg',                'http://demo_content.tagdiv.com/Newspaper_6/nomad/about_bg.jpg');
td_demo_media::add_image_to_media_gallery('td_search_bg',               'http://demo_content.tagdiv.com/Newspaper_6/nomad/search_bg.jpg');
td_demo_media::add_image_to_media_gallery('td_404_bg',                  'http://demo_content.tagdiv.com/Newspaper_6/nomad/404_bg.jpg');
