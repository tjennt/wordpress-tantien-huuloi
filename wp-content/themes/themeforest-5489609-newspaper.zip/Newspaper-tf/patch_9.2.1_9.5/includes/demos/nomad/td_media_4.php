<?php
/**
 * Created by ra on 6/13/2015.
 */


td_demo_media::add_image_to_media_gallery('td_food_bg',                  "http://demo_content.tagdiv.com/Newspaper_6/nomad/food_bg.jpg");
td_demo_media::add_image_to_media_gallery('td_culture_bg',               "http://demo_content.tagdiv.com/Newspaper_6/nomad/culture_bg.jpg");
td_demo_media::add_image_to_media_gallery('td_nature_bg',                "http://demo_content.tagdiv.com/Newspaper_6/nomad/nature_bg.jpg");
td_demo_media::add_image_to_media_gallery('td_wildlife_bg',              "http://demo_content.tagdiv.com/Newspaper_6/nomad/wildlife_bg.jpg");